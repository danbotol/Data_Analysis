# Loan Dataset Exploration
# by Adetola Oladipo


# Dataset

> This dataset contains 113,937 loans with 81 variables on each loan.

> Created a new column to make necessary deductions.



# Summary of Findings

> Occupation taggged as other has the largest number of loans which could be related to its unknown origin. CA has the most loans across all states

> IncomeRange and LoanOriginalAmount are closely related because the charts shows a higher loan amount for higher earners.

> The Employed status having no value, it more likely the status was mistakenly left in the dataset. Loan rate is different across states

> There are noticeable differences between rates at 12months and 60months across all states



# Key Insights for Presentation


> These factors determine the Loan outcome status of a borrower; CreditGrade, BorrowerRate, EmploymentStatus, Occupation, IsBorrowerHomeowner, IncomeRange, LoanOriginalAmount, Term.

> Also, these factors affect the interest rate of a borrower;BorrowerState, CreditGrade, EmploymentStatus, Occupation, IsBorrowerHomeowner, IncomeRange, LoanOriginalAmount, Term, BorrowerRate.

